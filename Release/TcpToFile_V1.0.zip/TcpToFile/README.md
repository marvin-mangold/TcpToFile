# TcpToFile
Save Data as CSV via TCP from multiple Clients
